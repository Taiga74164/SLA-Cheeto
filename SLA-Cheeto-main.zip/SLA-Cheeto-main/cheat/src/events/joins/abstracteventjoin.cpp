#include "abstracteventjoin.h"


namespace events::joins 
{
	AbstractEventJoin::AbstractEventJoin() {}

	AbstractEventJoin::~AbstractEventJoin() {}
}
