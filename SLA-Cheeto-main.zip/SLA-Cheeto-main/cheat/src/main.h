#pragma once
#include <Windows.h>

void Run(HMODULE hModule);